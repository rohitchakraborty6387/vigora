<?php 

if (isset($_POST['submit'])) {
    $user_name = $_POST['name'];
    $user_phone = $_POST['phone'];
    $address = $_POST['address'];

    // Check if phone number is already used
    $phone_file = 'phone_numbers.txt';
    $phone_numbers = file_exists($phone_file) ? file($phone_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];

    if (in_array($user_phone, $phone_numbers)) {
        echo "Error: This phone number has already been used to submit a lead.";
        exit();
    }

    // If phone number is new, save it and proceed
    file_put_contents($phone_file, $user_phone . "\n", FILE_APPEND);

    $user_id = 50374;
    $country_code = 'IN';
    $offer_id = 8948;

    $api_key = '0bfaf8279091688870a58115858a42c0';

    $request_data = [
        "user_id" => $user_id,
        "data" => [
            "name" => $user_name,
            "country" => $country_code,
            "phone" => $user_phone,
            "address" => $address,
            "offer_id" => $offer_id
        ]
    ];

    $check_sum = sha1(json_encode($request_data) . $api_key);
    
    // Send request
    $ch = curl_init("http://tl-api.com/api/lead/create?check_sum={$check_sum}");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($request_data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Content-Length: ' . strlen(json_encode($request_data))
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    $response_data = json_decode($response, true);
    if ($response_data['status'] === 'ok') {
        // Store user data in a text file
        $file = 'user_data.txt';
        $data = "Name: $user_name, Phone: $user_phone\n";
        file_put_contents($file, $data, FILE_APPEND);

        // Redirect to thank you page with lead ID
        header("Location: thank_you.php?lead_id=" . $response_data['data']['id']);
        exit();
    } else {
        echo "Error: " . $response_data['error'];
    }
}
?>

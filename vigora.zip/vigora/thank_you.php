<?php
// Check if the 'subid' exists in the cookie
// if(isset($_COOKIE['subid'])) {
//     $subid = $_COOKIE['subid'];
    
//     // Send postback to both URLs with the 'subid' and 'status=lead'
//     file_get_contents('http://161.35.3.44/87d2e06/postback?subid='. $subid .'&status=lead&payout=');
// } else {
//     echo "No subid found in the cookie.";
// }
if (isset($_COOKIE['subid'])) {
    $subid = $_COOKIE['subid'];
    $lead_id = $_GET['lead_id'];

    // Send postback to both URLs with 'subid' and 'status=lead'
    $postback_url = 'http://161.35.3.44/87d2e06/postback?subid=' . $subid . '&status=lead&payout=&lead_id=' . $lead_id;
    file_get_contents($postback_url);
} else {
    echo "No subid found in the cookie.";
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Thank You!</h2>
        <p>Your submission has been received successfully.</p>
        <a href="./index.html" class="btn btn-primary">Submit Another Lead</a>
    </div>
</body>
</html>

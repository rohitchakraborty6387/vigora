<?php


$user_id = 50374;  // Your user ID
$user_name = "John Doe";  // User's name
$country_code = "US";  // Country code
$user_phone = "+1234567890";  // User's phone
$offer_id = 8948;  // Offer ID
$api_key = "0bfaf8279091688870a58115858a42c0";  // Your API key

// Prepare request data
$request_data = [
    "user_id" => $user_id,
    "data" => [
        "name" => $user_name,
        "country" => $country_code,
        "phone" => $user_phone,
        "offer_id" => $offer_id
    ]
];

// Create checksum
$check_sum = sha1(json_encode($request_data) . $api_key);

// Send request
$ch = curl_init("http://tl-api.com/api/lead/create?check_sum={$check_sum}");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($request_data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Content-Length: ' . strlen(json_encode($request_data))
]);

$response = curl_exec($ch);
curl_close($ch);

// Handle response
$response_data = json_decode($response, true);
if ($response_data['status'] === 'ok') {
    echo "Lead sent successfully. Lead ID: " . $response_data['data']['id'];
} else {
    echo "Error: " . $response_data['error'];
}
